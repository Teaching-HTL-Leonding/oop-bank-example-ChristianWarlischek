﻿using Banking.Logic;
using Microsoft.VisualBasic;
using System.Security.Principal;

Console.WriteLine("Banking System");
Console.WriteLine("==============");

Account myAccount;

bool isRightType = false;

while (!isRightType)
{
    Console.Write("Enter Type of Account.. [c]checking Account, [b]business Account, [s]savings Account: ");
    var accountType = Console.ReadLine();

    if (accountType == "c" || accountType == "C")
    {
        Console.WriteLine("Checking Account");
        Console.WriteLine("================");

        myAccount = new CheckingAccount();

        Console.Write("What is your account number? ");
        myAccount.AccountNumber = Console.ReadLine()!;

        Console.Write("Account holder: ");
        myAccount.AccountHolder = Console.ReadLine()!;

        Console.Write("Current balance: ");
        myAccount.CurrentBalance = decimal.Parse(Console.ReadLine()!);

        Console.WriteLine("========================================");

        var transection = new Transaction();

        Console.Write("Transaction acount number: ");
        transection.AccountNumber = Console.ReadLine()!;

        Console.Write("Transaction description: ");
        transection.Description = Console.ReadLine()!;

        Console.Write("Transaction amount: ");
        transection.Amount = decimal.Parse(Console.ReadLine()!);

        Console.Write("Transaction timestamp: ");
        transection.Timestamp = DateTime.Parse(Console.ReadLine()!);

        if (myAccount.TryExecute(transection))
        {
            Console.WriteLine($"Transaction successfully. Your new current balance is {myAccount.CurrentBalance}.");
        }
        else
        {
            Console.WriteLine("Transaction is not allowed, please try it again.");
        }

        isRightType = true;
    }
    else if (accountType == "b" || accountType == "B")
    {
        Console.WriteLine("Business Account");
        Console.WriteLine("================");

        myAccount = new BusinessAccount();
        Console.Write("What is your account number? ");
        myAccount.AccountNumber = Console.ReadLine()!;

        Console.Write("Account holder: ");
        myAccount.AccountHolder = Console.ReadLine()!;

        Console.Write("Current balance: ");
        myAccount.CurrentBalance = decimal.Parse(Console.ReadLine()!);

        Console.WriteLine("========================================");

        var transection = new Transaction();

        Console.Write("Transaction acount number: ");
        transection.AccountNumber = Console.ReadLine()!;

        Console.Write("Transaction description: ");
        transection.Description = Console.ReadLine()!;

        Console.Write("Transaction amount: ");
        transection.Amount = decimal.Parse(Console.ReadLine()!);

        Console.Write("Transaction timestamp: ");
        transection.Timestamp = DateTime.Parse(Console.ReadLine()!);

        if (myAccount.TryExecute(transection))
        {
            Console.WriteLine($"Transaction successfully. Your new current balance is {myAccount.CurrentBalance}.");
        }
        else
        {
            Console.WriteLine("Transaction is not allowed, please try it again.");
        }

        isRightType = true;
    }
    else if (accountType == "s" || accountType == "S")
    {
        Console.WriteLine("Savings Account");
        Console.WriteLine("===============");

        myAccount = new SavingsAccount();
        Console.Write("What is your account number? ");
        myAccount.AccountNumber = Console.ReadLine()!;

        Console.Write("Account holder: ");
        myAccount.AccountHolder = Console.ReadLine()!;

        Console.Write("Current balance: ");
        myAccount.CurrentBalance = decimal.Parse(Console.ReadLine()!);

        Console.WriteLine("========================================");

        var transection = new Transaction();

        Console.Write("Transaction acount number: ");
        transection.AccountNumber = Console.ReadLine()!;

        Console.Write("Transaction description: ");
        transection.Description = Console.ReadLine()!;

        Console.Write("Transaction amount: ");
        transection.Amount = decimal.Parse(Console.ReadLine()!);

        Console.Write("Transaction timestamp: ");
        transection.Timestamp = DateTime.Parse(Console.ReadLine()!);

        if (myAccount.TryExecute(transection))
        {
            Console.WriteLine($"Transaction successfully. Your new current balance is {myAccount.CurrentBalance}.");
        }
        else
        {
            Console.WriteLine("Transaction is not allowed, please try it again.");
        }

        isRightType = true;
    }
    else
    {
        Console.WriteLine("Sorry, invalid Input!");

    }
}