﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking.Logic
{
    public class SavingsAccount : Account
    {
        public override bool IsAllowed(Transaction trans)
        {
            if (CurrentBalance >= 0 && CurrentBalance <= 100000000 && CurrentBalance + trans.Amount < 100000000 && CurrentBalance - trans.Amount > 0)
            {
                return true;
            }
            else
                return false;
        }
    }
}
