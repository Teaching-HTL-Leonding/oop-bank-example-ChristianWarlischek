﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking.Logic
{
    public class Transaction
    {
        public string AccountNumber { get; set; } = "12122323";
        public string Description { get; set; } = "Hello";
        public DateTime Timestamp { get; set; }
        public decimal Amount { get; set; }
    }
}
