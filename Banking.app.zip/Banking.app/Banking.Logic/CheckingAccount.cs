﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking.Logic
{
    public class CheckingAccount : Account
    {
        public override bool IsAllowed(Transaction trans)
        {
            if (CurrentBalance >= -10000 && CurrentBalance <= 10000000 && CurrentBalance + trans.Amount <= 10000000 && CurrentBalance - trans.Amount >= -10000 && trans.Amount <= 10000)
            {
                return true;
            }

            else
                return false;
        }
    }
}
