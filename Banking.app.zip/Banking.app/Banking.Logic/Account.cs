﻿namespace Banking.Logic
{
    public abstract class Account
    {
        public string AccountNumber { get; set; } = "";
        public string AccountHolder { get; set; } = "";
        public decimal CurrentBalance { get; set; }

        public abstract bool IsAllowed(Transaction trans);

        public bool TryExecute(Transaction trans)
        {
            if(IsAllowed(trans))
            {
                CurrentBalance = CurrentBalance + trans.Amount;
                return true;
            }
            return false;
        }


    }
}