﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking.Logic
{
    public class BusinessAccount: Account
    { 
        public override bool IsAllowed(Transaction trans)
        {
            if (CurrentBalance >= -1000000 && CurrentBalance <= 100000000 && CurrentBalance + trans.Amount < 100000000 && CurrentBalance - trans.Amount > 0 && trans.Amount <= 100000)
            {
                return true;
            }

            else
                return false;
        }
    }
    
}
